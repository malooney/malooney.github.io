

rm(list=ls())
cat("\014")

library(readxl)

# import and clean data --------------------------------------------------------
path.local <- try(rprojroot::find_rstudio_root_file(), silent=TRUE)

if(class(path.local) == 'try-error'){
  path.local <- getwd()
} else{}

Meat_Demand_Argentina <- read_excel(paste(path.local, "/data/Meat Demand Argentina.xls", sep=""))

dataMatrix <- Meat_Demand_Argentina[, c(8:13, 7)]
dataMatrix <- as.matrix(dataMatrix[ , ])
rm(Meat_Demand_Argentina)


# set 8, 4 to the rows of the dataMatrix to evaluate pairwise WARP
tmp <- dataMatrix[c(8,4),]
tmp

sum(tmp[1, 1:3]* tmp[1, 4:6]) >= sum(tmp[1, 1:3]* tmp[2, 4:6])
sum(tmp[2, 1:3]* tmp[1, 4:6]) > sum(tmp[2, 1:3]* tmp[2, 4:6])

if((sum(tmp[1, 1:3]* tmp[1, 4:6]) >= sum(tmp[1, 1:3]* tmp[2, 4:6]) & sum(tmp[2, 1:3]* tmp[2, 4:6]) >= sum(tmp[2, 1:3]* tmp[1, 4:6]))) {
  cat("WARP FAILED") 
} else { cat("WARP PASSED") 
}
